package com.example.serverusermanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerUserManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServerUserManagementApplication.class, args);
    }

}
